#!/bin/bash

#For loop runs the loop once for each value - in this case from 1 -> 5
for i in {1..5}
do
   #The variable "i" contains the current value of the loop - print this using $i
   echo "The current number is $i."
done

echo "second for loop - different spacing...."

#Spacing doesn't matter in bash - this will run the same as the first loop
for i in {1..5}
       do
echo "The current number is $i."
                          done


#!/bin/bash
#Run this script with: ./script3.sh arg1 arg2
echo "The script name that was run just now was: $0"
echo "The first argument was: $1"
echo "The second argument was: $2"
echo "Enter one or more words and press [ENTER]:"
read input
echo "You entered: $input"

#!/bin/bash
#First line is the shebang, which tells the system to use bash to execute this script

#Echo simply outputs (or prints) text to the string so the user can see it
echo "Simple program"
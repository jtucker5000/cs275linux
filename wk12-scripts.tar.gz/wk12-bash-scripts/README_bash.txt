Helpful bash info/tips below (from TestOut)

Other file.....

script1.sh:  Basic Hello World example

script2.sh:  For loop + spacing differences

script3.sh:  Reading input from command line and user

tcpdump_analyze.sh:  Full script with options to analyze
        output from tcpdump

tcpdump_analyze_case.sh:  Same script as above, but instead
        of multiple IF..ELSE, uses a CASE statement

sample_tcpdump.txt:  Sample tcpdump file to use with
        above program. Commands to generate on your own:
        sudo tcpdump -i any -nn -tttt > sample_tcpdump.txt
        sudo tcpdump -i any -nn -tttt -c 100 port 80 or port 443 or port 53 > sample_tcpdump.txt


=====================================================

Comments in bash    #

Scripts start with - one case where this isn't a comment
#!/bin/bash

Scripts need to be executable
chmod +x


Some common test command options include:
-d Checks whether a directory exists.
-f Checks whether a file exists and is a regular file.
-n Checks whether a string has a non-zero value.
-z Checks whether a string has a zero value.
-r Checks whether a file is readable.
-w Checks whether a file is writable.
-x Checks whether a file is executable.





[[Boolean or logical operators connect multiple values together so they can be evaluated:]]
&& Logical AND (this and that)
|| Logical OR (this or that)
! Logical NOT (not this)


An example of a logical operation (AND) in Bash: [ $var1 -ge $var2 ] && [ $var3 -le $var4 ].

An example of a string operation (concatenation) in Bash: $var1$var2.


Some comparison and string operators are identical:
-eq Equal to
-ne Not equal to
-gt Greater than
-ge Greater than or equal to
-lt Less than
-le Less than or equal to


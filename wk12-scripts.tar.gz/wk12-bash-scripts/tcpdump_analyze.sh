#!/bin/bash


# If an argument is provided, use it as the file, otherwise prompt the user
if [ -n "$1" ]; then
    FILE="$1"
else
    # Prompt user for tcpdump file
    read -p "Enter path to tcpdump output file: " FILE
fi

# Validate file exists
if [ ! -f "$FILE" ]; then
    echo "Error: File does not exist."
    exit 1
fi

# Function: Extract IP addresses (source and destination)
get_ips() {
    echo "Extracting IP addresses..."
    
    # Extract IPs using string commands
    # Multi-line statements use backslash to indicate continuation
    #   -- this prevents the command from becoming too long and hard to read
    # The command sequence:
    #   1. awk to get the 6th and 8th fields (source and destination)
    #   2. sed to remove colons
    #   3. tr to replace spaces with newlines (to get one IP per line)
    #   4. cut to get just the IP part (remove port numbers)
    #   5. sort and uniq to get unique IPs
    awk '{print $6, $8}' "$FILE" | \
    sed 's/://g' | \
    tr ' ' '\n' | \
    cut -d. -f1-4 | \
    sort | uniq
}

# Function: Count packets per IP
count_packets_per_ip() {
    echo "Counting packets per IP..."

    # Similar to previous function, but uses uniq -c to count occurrences and sort to show most active IPs first
    awk '{print $6, $8}' "$FILE" | \
    sed 's/://g' | \
    tr ' ' '\n' | \
    cut -d. -f1-4 | \
    sort | uniq -c | sort -nr
}

# Function: Count packets per protocol
count_protocols() {
    echo "Counting packets per protocol..."

    # Similar to above, but when we get the addresses, instead of getting rid of the port number,
    # we only want to get the port number (to identify the protocol).
    # Since this is for both source and destination traffic, we want to only focus on service level
    # ports (which are less than 1024).
    # The second awk command uses -F. to split on the dot and checks if the last field ($NF) is less than 1024.
    awk '{print $6, $8}' "$FILE" | \
    sed 's/://g' | \
    tr ' ' '\n' | \
    awk -F. '$NF < 1024 {print $NF}' | \
    sort | uniq -c | sort -nr

}

# Function: Top talkers (most active IPs)
top_talkers() {
    echo "Top 5 talkers (most packets):"

    # Same as count_packets_per_ip, but limit results to top 5 using head -5
    awk '{print $6, $8}' "$FILE" | \
    sed 's/://g' | \
    tr ' ' '\n' | \
    cut -d. -f1-4 | \
    sort | uniq -c | sort -nr | head -5
}


# Function: Count total packets
total_packets() {
    COUNT=$(wc -l < "$FILE")
    echo "Total packets: $COUNT"
}

# ==========================================
# Menu Loop (WHILE LOOP)
# By using "while true" we create an infinite loop that will keep showing the menu until the user chooses to exit.
# ==========================================
while true
do
    echo ""
    echo "===== TCPDump Analyzer Menu ====="
    echo "1. Show unique IP addresses"
    echo "2. Count packets per IP"
    echo "3. Count packets per protocol"
    echo "4. Show top 5 talkers"
    echo "5. Show total packet count"
    echo "6. Exit"
    echo "================================"

    read -p "Choose an option: " CHOICE

    # IF / ELIF decision structure
    if [ "$CHOICE" -eq 1 ]; then
        get_ips

    elif [ "$CHOICE" -eq 2 ]; then
        count_packets_per_ip

    elif [ "$CHOICE" -eq 3 ]; then
        count_protocols

    elif [ "$CHOICE" -eq 4 ]; then
        top_talkers

    elif [ "$CHOICE" -eq 5 ]; then
        total_packets

    elif [ "$CHOICE" -eq 6 ]; then
        echo "Exiting..."
        break

    else
        echo "Invalid option. Please try again."
    fi
done

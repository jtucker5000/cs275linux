#Range of 0 to 4
for i in range(5):
    print(i)

print('---------')

#Range of 1 to 5
for i in range(1, 6):
    print(i)

print('---------')

#Range of 0 to 9 with a step of 2
for i in range(0, 10, 2):
    print(i)

print('---------')

#Range of 0 to 5 with better message formatting
#f-strings are a way to format strings in Python. 
#They allow you to embed expressions inside string 
#literals, using curly braces {}
for counter in range(5):
    print(f"Loop iteration: {counter}")
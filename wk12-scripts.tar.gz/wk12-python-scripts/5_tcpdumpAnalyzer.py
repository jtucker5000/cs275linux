#!/usr/bin/env python3

import re
import sys
from collections import Counter
from rich.console import Console
from rich.table import Table

console = Console()

PATTERN = re.compile(r'IP\s+(\d+\.\d+\.\d+\.\d+)\.(\d+)\s*>\s*(\d+\.\d+\.\d+\.\d+)\.(\d+)')

def get_file():
    if len(sys.argv) > 1:
        return sys.argv[1]
    return input("Enter path to tcpdump output file: ")

def parse_file(file_path):
    with open(file_path, "r") as f:
        for line in f:
            match = PATTERN.search(line)
            if match:
                src_ip, src_port, dst_ip, dst_port = match.groups()
                yield src_ip, int(src_port), dst_ip, int(dst_port)

# 1. Unique IPs
def get_ips(records):
    ips = sorted({ip for r in records for ip in (r[0], r[2])})

    table = Table(title="Unique IP Addresses")
    table.add_column("IP Address", style="cyan")

    for ip in ips:
        table.add_row(ip)

    console.print(table)

# 2. Count packets per IP
def count_packets_per_ip(records):
    counter = Counter()
    for src, _, dst, _ in records:
        counter[src] += 1
        counter[dst] += 1

    table = Table(title="Packets per IP")
    table.add_column("IP Address", style="cyan")
    table.add_column("Packet Count", justify="right", style="magenta")

    for ip, count in counter.most_common():
        table.add_row(ip, str(count))

    console.print(table)

# 3. Count protocols (ports < 1024)
def count_protocols(records):
    counter = Counter()
    for _, sport, _, dport in records:
        if sport < 1024:
            counter[sport] += 1
        if dport < 1024:
            counter[dport] += 1

    table = Table(title="Well-Known Ports (<1024)")
    table.add_column("Port", style="cyan")
    table.add_column("Count", justify="right", style="magenta")

    for port, count in counter.most_common():
        table.add_row(str(port), str(count))

    console.print(table)

# 4. Top talkers
def top_talkers(records):
    counter = Counter()
    for src, _, dst, _ in records:
        counter[src] += 1
        counter[dst] += 1

    table = Table(title="Top 5 Talkers")
    table.add_column("IP Address", style="cyan")
    table.add_column("Packet Count", justify="right", style="magenta")

    for ip, count in counter.most_common(5):
        table.add_row(ip, str(count))

    console.print(table)

# 5. Total packets
def total_packets(file_path):
    with open(file_path) as f:
        count = sum(1 for _ in f)

    console.print(f"[bold green]Total packets:[/] {count}")

# Menu loop
def main():
    file_path = get_file()

    try:
        open(file_path).close()
    except FileNotFoundError:
        console.print("[bold red]Error: File does not exist.[/]")
        sys.exit(1)

    while True:
        console.print("""
[bold]
===== TCPDump Analyzer Menu =====
1. Show unique IP addresses
2. Count packets per IP
3. Count packets per protocol
4. Show top 5 talkers
5. Show total packet count
6. Exit
================================
[/]
""")

        choice = input("Choose an option: ").strip()

        if choice in {"1", "2", "3", "4"}:
            records = list(parse_file(file_path))

        if choice == "1":
            get_ips(records)
        elif choice == "2":
            count_packets_per_ip(records)
        elif choice == "3":
            count_protocols(records)
        elif choice == "4":
            top_talkers(records)
        elif choice == "5":
            total_packets(file_path)
        elif choice == "6":
            console.print("[bold yellow]Exiting...[/]")
            break
        else:
            console.print("[bold red]Invalid option.[/]")

if __name__ == "__main__":
    main()
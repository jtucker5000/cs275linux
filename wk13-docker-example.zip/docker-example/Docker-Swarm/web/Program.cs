using Microsoft.Data.SqlClient;
using Dapper;
using StackExchange.Redis;
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.Configuration;
using Microsoft.AspNetCore.Http;
using System;

var builder = WebApplication.CreateBuilder(args);

var sqlConnStr = builder.Configuration.GetConnectionString("Sql");
var redisConnStr = builder.Configuration["Redis:Connection"];

var app = builder.Build();

var redis = ConnectionMultiplexer.Connect(redisConnStr);
var cache = redis.GetDatabase();

app.MapGet("/", async () =>
{
    string cacheKey = "demo:data";
    var machine = Environment.MachineName;


    // Try Redis first
    var cached = await cache.StringGetAsync(cacheKey);
    if (!cached.IsNullOrEmpty)
    {
        return Results.Ok(new { source = "redis", machine = machine, data = cached.ToString() });
    }

    // Query SQL
    using var conn = new SqlConnection(sqlConnStr);
    var result = await conn.QueryFirstOrDefaultAsync<string>(
        "UPDATE Table1 SET Counter = Counter + 1; SELECT TOP 1 Counter FROM Table1");

    result ??= "No data";

    // Store in Redis
    await cache.StringSetAsync(cacheKey, result, TimeSpan.FromSeconds(10));

    return Results.Ok(new { source = "sql", machine = machine, data = result });
});

app.Run();
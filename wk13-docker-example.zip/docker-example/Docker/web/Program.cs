using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.Configuration;
using Microsoft.AspNetCore.Http;
using System;

var builder = WebApplication.CreateBuilder(args);


var app = builder.Build();


app.MapGet("/", async () =>
{
    return Results.Ok("Hello World");
});

app.Run();
# Build the image
podman build -t demo-web:latest ./Docker-Compose/web

# Run with network and port mapping
podman run -p 8088:8080 \
  -e ConnectionStrings__Sql=Server=sql... \
  -e Redis__Connection=redis:6379 \
  demo-web:latest

# Ubuntu/Debian
sudo apt-get install podman podman-compose

# Fedora/RHEL
sudo dnf install podman podman-compose


# view images
podman images

# view running containers
podman ps

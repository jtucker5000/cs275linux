IF NOT EXISTS (SELECT name FROM sys.databases WHERE name = 'DemoDb')
BEGIN
    CREATE DATABASE DemoDb;
END
GO

USE DemoDb;
GO

IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'Table1')
BEGIN
    CREATE TABLE Table1 (
        Id INT PRIMARY KEY IDENTITY(1,1),
        LastStart DATETIME,
        Counter INT
   );

   INSERT INTO Table1 (LastStart, Counter)
   SELECT GETDATE(), 0
END
GO

UPDATE Table1 SET LastStart = GETDATE(), Counter = 0